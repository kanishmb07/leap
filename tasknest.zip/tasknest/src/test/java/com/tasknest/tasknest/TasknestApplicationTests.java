package com.tasknest.tasknest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasknestApplicationTests {

	@Test
	void contextLoads() {
	}

}
