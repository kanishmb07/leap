package com.tasknest.tasknest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasknestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasknestApplication.class, args);
	}

}
